package com.example.medvend

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
